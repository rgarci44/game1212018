﻿using Assets;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TreeRectDebug : MonoBehaviour
{

    public int levelWidth = 20;
    public int levelHeight = 20;
    public int roomX = 0;
    public int roomY = 0;
    public int roomWidth = 9;
    public int roomHeight = 9;

    // Use this for initialization
    void Start()
    {

        string[,] level = new string[levelWidth, levelHeight];
        System.Text.StringBuilder sb = new System.Text.StringBuilder();

        BinaryTree<RectInt> sampleRectTree;
        sampleRectTree = new BinaryTree<RectInt>(new RectInt(0, 0, levelWidth, levelHeight));
        //List<BinaryTreeNode<RectInt>> Leaves = new List<BinaryTreeNode<RectInt>>();

        int partitionWidth = levelWidth / 2;
        int partitonHeight = levelHeight;
        int partitionHeightQuad = levelHeight / 2;

        RectInt leftPartitionRect = new RectInt(0, 0, partitionWidth, partitonHeight);
        BinaryTreeNode<RectInt> leftPartitionNode = sampleRectTree.Root().AddChild(leftPartitionRect);

        int rightPartitonX = levelWidth / 2;
        int rightPartititonY = 0;
        RectInt rightPartitionRect = new RectInt(rightPartitonX, rightPartititonY, partitionWidth, partitonHeight);
        BinaryTreeNode<RectInt> rightPartitionNode = sampleRectTree.Root().AddChild(rightPartitionRect);
        //BinaryTreeNode<RectInt> rightPartitionNode = sampleRectTree.Root().AddChild(Split(rightPartitonX, rightPartititonY, partitionWidth, partitonHeight,));
        ///////////////////////////////////////////////////////////


        int quadY = levelHeight / 2;

        RectInt topLeftPartitionRect = new RectInt(0, quadY, partitionWidth, partitionHeightQuad);
        BinaryTreeNode<RectInt> topLeftPartitionNode = leftPartitionNode.AddChild(topLeftPartitionRect);


        RectInt bottomLeftPartitionRect = new RectInt(0, 0, partitionWidth, partitionHeightQuad);
        BinaryTreeNode<RectInt> bottomLeftPartitionNode = leftPartitionNode.AddChild(bottomLeftPartitionRect);


        RectInt topRightPartitionRect = new RectInt(0, quadY, partitionWidth, partitionHeightQuad);
        BinaryTreeNode<RectInt> topRightPartitionNode = rightPartitionNode.AddChild(topRightPartitionRect);


        RectInt bottomRightPartitionRect = new RectInt(0, 0, partitionWidth, partitionHeightQuad);
        BinaryTreeNode<RectInt> bottomRightPartitionNode = rightPartitionNode.AddChild(bottomRightPartitionRect);

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        RectInt topLeftRoom = new RectInt(1, quadY + 1, roomWidth, roomHeight);
        BinaryTreeNode<RectInt> topLeftRoomNode = topLeftPartitionNode.AddChild(topLeftRoom);


        RectInt bottomLeftRoom = new RectInt(1, 1, roomWidth, roomHeight);
        BinaryTreeNode<RectInt> bottomLeftRoomNode = bottomLeftPartitionNode.AddChild(bottomLeftRoom);


        RectInt topRightRoom = new RectInt(1, quadY + 1, roomWidth, roomHeight);
        BinaryTreeNode<RectInt> topRightRoomNode = topRightPartitionNode.AddChild(topRightRoom);


        RectInt bottomRightRoom = new RectInt(1, 1, roomWidth, roomHeight);
        BinaryTreeNode<RectInt> bottomRightRoomNode = bottomRightPartitionNode.AddChild(bottomRightRoom);


        // RectInt leftPartitionWorld = NodeRectWorld(leftPartitionNode);
        // RectInt rightPartitionWorld = NodeRectWorld(rightPartitionNode);
        // print("Left: " + leftPartitionWorld);
        // print("Right: " + rightPartitionWorld);
        ////////////////////////////////////////////////////////////////////////////


        RectInt topLeftPartitionWorld = NodeRectWorld(topLeftPartitionNode);
        RectInt bottomLeftPartitionWorld = NodeRectWorld(bottomLeftPartitionNode);
        RectInt topRightPartitionWorld = NodeRectWorld(topRightPartitionNode);
        RectInt bottomRightPartitionWorld = NodeRectWorld(bottomRightPartitionNode);

        /////////////////////////////////////////////////////////////////////////////

        RectInt topLeftRoomWorld = NodeRectWorld(topLeftRoomNode);
        RectInt bottomLeftRoomWorld = NodeRectWorld(bottomLeftRoomNode);
        RectInt topRightRoomWorld = NodeRectWorld(topRightRoomNode);
        RectInt bottomRightRoomWorld = NodeRectWorld(bottomRightRoomNode);

        RectInt[] childRects = new RectInt[] { topLeftPartitionWorld, bottomLeftPartitionWorld, topRightPartitionWorld, bottomRightPartitionWorld };
        RectInt[] childRooms = new RectInt[] { topLeftRoomWorld, bottomLeftRoomWorld, topRightRoomWorld, bottomRightRoomWorld };

        print("Top Left: " + topLeftPartitionWorld);
        print("Bottom Left: " + bottomLeftPartitionWorld);
        print("Top Right: " + topRightPartitionWorld);
        print("Bottom Right: " + bottomRightPartitionWorld);


            // List<BinaryTreeNode<RectInt>> topLeft = new List<BinaryTreeNode<RectInt>>();
            // List<BinaryTreeNode<RectInt>> bottomLeft = new List<BinaryTreeNode<RectInt>>();
            // List<BinaryTreeNode<RectInt>> topRight = new List<BinaryTreeNode<RectInt>>();
            // List<BinaryTreeNode<RectInt>> bottomRight = new List<BinaryTreeNode<RectInt>>();
            //for (int i = 0; i < partitionWidth; i++)
            //  {
            //      for (int j = 0; i < quadY; j++)
            //      {
            //              level[i, j] =
            //              print(level[i, j]);
            //      }
            //  }
            ////////////////////////////////////////////////////////////////////////////////

            for (int r = 0; r < childRects.Length; r++)
        {
            RectInt currentRect = childRects[r];
            RectInt currentRoom = childRooms[r];
            /*
            for (int i = currentRect.x; i < currentRect.x + currentRect.width; i++)
            {
                for (int j = currentRect.y; j < currentRect.y + currentRect.height; j++)
                {
                    level[i, j] = (r + 1).ToString();
                }
            }

            for (int i = currentRect.x + 1; i < currentRect.x + currentRect.width; i++)
            {
                for (int j = currentRect.y + 1; j < currentRect.y + currentRect.height; j++)
                {
                    level[i, j] = (r).ToString();
                }
            }
            */

            for (int i = currentRect.x; i < currentRect.x + currentRect.width; i++)
            {
                for (int j = currentRect.y; j < currentRect.y + currentRect.height; j++)
                {
                    level[i, j] = ("0").ToString();
                }
            }

            for (int i = currentRoom.x; i < currentRoom.width; i++)
            {
                for (int j = currentRoom.y; j < currentRoom.height; j++)
                {
                    level[i, j] = ("1").ToString();
                }
            }

        }

        for (int y = 0; y < levelHeight; y++)
        {
            for (int x = 0; x < levelWidth; x++)
            {
                sb.Append(level[x, y] + " ");
            }
            sb.AppendLine();
        }


        print(sb.ToString());

    }

    private RectInt NodeRectWorld(BinaryTreeNode<RectInt> node)
    {
        BinaryTreeNode<RectInt> current = node;
        RectInt rectWorld = node.Value();
        rectWorld.x = 0;
        rectWorld.y = 0;

        while (current != null)
        {
            rectWorld.x += current.Value().x;
            rectWorld.y += current.Value().y;
            
            current = current.parent;
        }
        return rectWorld;

    }

    private void Split(int partitionX, int partitionY, int partitionWidth, int partitionHeight, BinaryTreeNode<RectInt> node)
    {
        BinaryTreeNode<RectInt> current = node;
        RectInt partitionRect = new RectInt(partitionX, partitionY, partitionWidth, partitionHeight);
        BinaryTreeNode<RectInt> partitionNode = current.AddChild(partitionRect);
    }
}
