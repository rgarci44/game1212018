﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleWASD : MonoBehaviour
{
    public GameObject Waypoint;
    public float speed = 0.5f;

    private CharacterController myController;
    public LayerMask raycastLayers;

    public float rayDistance = 0.1f;


    private Vector3 rayCollisionNormal;
    private Vector3 hitLocationThisFrame = Vector3.zero;
    private bool hitThisFrame = false;

    private Vector3 target = Vector3.zero;
    private bool isSeekTargetSet;
    public float moveSpeed = 5.0f;
    public float radiusOfSatisfaction = 0.01f;
    public float radiusOfApproach = 1.00f;
    public float approach = 0.0f;


    // Use this for initialization
    void Start()
    {
        myController = GetComponent<CharacterController>();
        
    }

    // Update is called once per frame
    void Update()
    {

        Movement();
       
       
    }


    void Movement()
    {

        Vector3 moveDirection = Vector3.zero;


        RaycastHit hitInfo;
        
        Seek(Waypoint.transform.position);
        if (isSeekTargetSet)
        {

           

            // Go up
            if (Physics.Raycast(transform.position, transform.forward, out hitInfo, 3.0f))
            {
                moveDirection = Vector3.back;
                myController.Move(moveDirection.normalized * moveSpeed * Time.deltaTime);
            }
            if (Physics.Raycast(transform.position, -transform.right, out hitInfo, 3.0f))
            {
                moveDirection = Vector3.right;
                myController.Move(moveDirection.normalized * moveSpeed * Time.deltaTime);
            }
            // Go down
            if (Physics.Raycast(transform.position, -transform.forward, out hitInfo, 3.0f))
            {
                moveDirection = Vector3.forward;
                myController.Move(moveDirection.normalized * moveSpeed * Time.deltaTime);


            if (Physics.Raycast(transform.position, transform.right, out hitInfo, 3.0f))
            {
                    moveDirection = Vector3.left;
                    myController.Move(moveDirection.normalized * moveSpeed * Time.deltaTime);
            }
               
               
            }

            //myController.Move(moveDirection.normalized * moveSpeed * Time.deltaTime);
            //moveDirection += target - transform.position;


            //if (hitInfo.transform.z ) 

            

            /*
            if (Vector3.Distance(target, transform.position) <= radiusOfApproach)
            {

                myController.Move(moveDirection.normalized * moveSpeed * Time.deltaTime);
                if (Vector3.Distance(target, transform.position) <= radiusOfSatisfaction)
                {
                    isSeekTargetSet = false;
                }
            }*/
        }

       

        /*
        if (Input.GetKey(KeyCode.W)) moveDirection += Vector3.forward;
        if (Input.GetKey(KeyCode.A)) moveDirection -= Vector3.right;
        if (Input.GetKey(KeyCode.S)) moveDirection -= Vector3.forward;
        if (Input.GetKey(KeyCode.D)) moveDirection += Vector3.right;

        if (moveDirection != Vector3.zero)
        {
            myController.Move(moveDirection.normalized * speed * Time.deltaTime);
        }
        */



    }
    public void Seek(Vector3 position)
    {
        target = position;
        target.y = transform.position.y;
        isSeekTargetSet = true;
    }


    private void OnDrawGizmos()
        {

            // Up
            Gizmos.color = Color.green;
            Gizmos.DrawLine(transform.position, transform.position + transform.forward * rayDistance);

        // Down
        Gizmos.color = Color.blue;
        Gizmos.DrawLine(transform.position, transform.position + -transform.forward * rayDistance);

        // Left

        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(transform.position, transform.position + -transform.right * rayDistance);


        // Right
        Gizmos.color = Color.magenta;
        Gizmos.DrawLine(transform.position, transform.position + transform.right * rayDistance);
    }

}